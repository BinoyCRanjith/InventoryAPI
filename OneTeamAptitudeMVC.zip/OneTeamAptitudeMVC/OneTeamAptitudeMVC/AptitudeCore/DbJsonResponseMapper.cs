﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OneTeamAptitudeMVC.AptitudeCore
{
    internal class DbJsonResponseMapper
    {
        public string Data { get; set; }
    }
}